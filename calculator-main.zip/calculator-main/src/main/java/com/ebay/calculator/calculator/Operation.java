package com.ebay.calculator.calculator;

public enum Operation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE
}
