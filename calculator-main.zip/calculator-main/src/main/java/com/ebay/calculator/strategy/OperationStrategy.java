package com.ebay.calculator.strategy;

public interface OperationStrategy {
    Number apply(Number num1, Number num2);

}
